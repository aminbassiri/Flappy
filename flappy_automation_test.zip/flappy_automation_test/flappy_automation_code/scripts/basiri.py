#!/usr/bin/env python
import rospy
import numpy as np
import math

from sensor_msgs.msg import LaserScan
from geometry_msgs.msg import Vector3

# Publisher baraye cmd velocity
cmd = rospy.Publisher('/flappy_acc', Vector3, queue_size=1)


#gaine x ,y
speed_gain = 1.7
pos_gain = 0.06

#meghdar dehi avalie
goal = [0, 0]
scan = [0,0,0,0,0,0,0,0,0]


def initNode():
    rospy.init_node('amin_code', anonymous=True)

    rospy.Subscriber("/flappy_vel", Vector3,vel)
    rospy.Subscriber("/flappy_laser_scan", LaserScan, laser)
    rospy.spin()



def vel(msg):
    #tabdil x,y be zavieh
    error_deg =math.atan2(goal[1],goal[0])/math.pi*180
    #sakht harekat namaey 2^x baraye y va khati bara x
    ref_vx = speed_gain*np.exp(-0.02*np.abs(error_deg)*2) 
    ref_vy = pos_gain*(error_deg/1)
    #mohasebe khata tanasobi
    err_x = ref_vx - msg.x
    err_y = ref_vy - msg.y
    #frestadan dastor x,y,z  va normal kardan ba zarib 30
    print (30*err_x,30*err_y)
    cmd.publish(30*err_x,30*err_y,0)


def angle():	
    goal_angle = 0
    # sakht arayeh gapha
    goals = [ i for i, e in enumerate(scan) if e == 0 ]
    #tabdil arayeh be zavieh -45 hade aghale zavie
    for i in goals:
        goal_angle += -45+10/2 + i*10
    #peida kardan zavieh ba tavajoh be inke age bishtar az 1 ki gap dasht miangiri anjam midahad
    return goal_angle/len(goals) if len(goals) > 1 else goal_angle


def laser(msg):

    global goal, scan
    # sakht arayeh 0 va 1 baraye bord kamtar az 1.9
    scan = [1 if i<=1.9 else 0 for i in msg.ranges]
    goal_angle = angle()

    last_goal_angle = math.atan2(goal[1],goal[0])/math.pi*180
    #peyda kardan khataye zavieh ey va miangin 
    error_deg = round((goal_angle + last_goal_angle)/2)

    # tabdile zavie be x,,y
    goal = [2*math.cos(np.deg2rad(error_deg)) , 2*math.sin(np.deg2rad(error_deg))]
    #print(goal)

if __name__ == '__main__':
    try:
        initNode()
    except rospy.ROSInterruptException:
        pass
